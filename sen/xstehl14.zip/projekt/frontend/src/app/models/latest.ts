export class Latest {
    temperature;
    humidity;
    pressure;
    light;
    moisture;
}
